package com.example.lab05_transferactivitylukyanov;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    CheckBox chB1, chB2;
    Boolean first, second;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editTextFirst);
        chB1 = findViewById(R.id.checkBox1);
        chB2 = findViewById(R.id.checkBox2);
    }

    public void OpenDiag(View v)
    {
        String s = editText.getText().toString();
        first = chB1.isChecked();
        second = chB2.isChecked();

        Intent i = new Intent(this, SecondActivity.class);
        i.putExtra("Transfer", s);
        i.putExtra("chB1", first);
        i.putExtra("chB2", second);

        startActivityForResult(i, 123);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        if (requestCode == 123)
        {
            if (data != null)
            {
                String s = data.getStringExtra("Transfer");
                first = data.getBooleanExtra("sw1", false);
                second = data.getBooleanExtra("sw2", false);
                chB1.setChecked(first);
                chB2.setChecked(second);

                Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
                editText.setText(s);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void CloseApp(View v)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);


        builder.setTitle("Confirm close").setMessage("Are you sure?"
        ).setPositiveButton("Yes", new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        }).setIcon(R.drawable.exit).show();

    }
}