package com.example.lab05_transferactivitylukyanov;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    EditText editText2;
    Switch sw1, sw2;
    Boolean first, second;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        editText2 = findViewById(R.id.editTextSecond);
        sw1 = findViewById(R.id.switch1);
        sw2 = findViewById(R.id.switch2);

        Intent i = getIntent();

        String s = i.getStringExtra("Transfer");
        first = i.getBooleanExtra("chB1", false);
        second = i.getBooleanExtra("chB2", false);

        sw1.setChecked(first);
        sw2.setChecked(second);

        editText2.setText(s);
    }

    public void OK(View v)
    {
        Intent i = new Intent();
        String s = editText2.getText().toString();
        first = sw1.isChecked();
        second = sw2.isChecked();

        i.putExtra("Transfer", s);
        i.putExtra("sw1", first);
        i.putExtra("sw2", second);

        setResult(RESULT_OK, i);
        finish();
    }

    public void Cancel(View v)
    {
        setResult(RESULT_CANCELED);
        finish();
    }
}