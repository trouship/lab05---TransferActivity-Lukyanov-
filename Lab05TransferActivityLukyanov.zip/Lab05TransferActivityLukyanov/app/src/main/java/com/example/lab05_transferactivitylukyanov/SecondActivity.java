package com.example.lab05_transferactivitylukyanov;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    EditText editText2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        editText2 = findViewById(R.id.editTextSecond);

        Intent i = getIntent();

        String s = i.getStringExtra("Transfer");
        editText2.setText(s);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,@Nullable Intent data)
    {
        if (requestCode == 123)
        {
            if (data != null)
            {
                String s = data.getStringExtra("Transfer");
                Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
                editText2.setText(s);
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }
    public void OK(View v)
    {

    }

    public void Cancel(View v)
    {

    }
}